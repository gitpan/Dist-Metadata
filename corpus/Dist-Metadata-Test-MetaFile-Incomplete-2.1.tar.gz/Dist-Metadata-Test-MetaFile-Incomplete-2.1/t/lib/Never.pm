package Never;
# ABSTRACT: Never index this

1;
